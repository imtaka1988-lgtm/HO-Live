const express = require("express");

let anchorAvatarColumnReady = false;

async function ensureAnchorAvatarColumn(pool) {
  if (anchorAvatarColumnReady) return;
  try {
    await pool.query("ALTER TABLE rooms ADD COLUMN anchor_avatar VARCHAR(500) NOT NULL DEFAULT ''");
  } catch (err) {
    if (!/Duplicate column/i.test(err.message || "")) throw err;
  }
  anchorAvatarColumnReady = true;
}

async function loadEnabledStreams(pool, roomId) {
  const [streams] = await pool.query(
    "SELECT id, name, type, url, is_default AS isDefault, enabled, priority FROM room_streams WHERE room_id = ? AND enabled = 1 AND url != '' ORDER BY priority, id",
    [roomId]
  );
  return streams.map(s => ({ ...s, default: s.isDefault === 1, isDefault: undefined }));
}

module.exports = function (pool) {
  const router = express.Router();

  router.get("/public/rooms", async (req, res) => {
    try {
      await ensureAnchorAvatarColumn(pool);
      const [rooms] = await pool.query(
        "SELECT id, title, category, status, cover, anchor_avatar AS anchorAvatar, anchor_name AS anchorName, sort_order AS sortOrder, COALESCE(announcement, '') AS announcement FROM rooms ORDER BY sort_order, id"
      );

      for (const room of rooms) {
        room.streams = await loadEnabledStreams(pool, room.id);
      }

      res.json({ ok: true, rooms });
    } catch (err) {
      console.error("[public rooms]", err);
      res.status(500).json({ ok: false, error: "服务暂时不可用" });
    }
  });

  return router;
};
